-- The Global Aggregate — MVP schema
-- Run this once in Supabase: Project → SQL Editor → New Query → paste → Run

create extension if not exists pgcrypto;

create table if not exists articles (
  id uuid primary key default gen_random_uuid(),
  source text not null,
  country text not null,          -- ISO 3166-1 alpha-2 code, e.g. 'US', 'IN'
  topic text not null default 'World',
  title text not null,
  url text not null unique,
  published_at timestamptz,
  created_at timestamptz not null default now()
);

create index if not exists articles_country_idx on articles (country);
create index if not exists articles_topic_idx on articles (topic);
create index if not exists articles_published_idx on articles (published_at desc);

create table if not exists user_preferences (
  user_id uuid primary key references auth.users (id) on delete cascade,
  country_list text[] not null default '{}',
  topic_list text[] not null default '{}',
  updated_at timestamptz not null default now()
);

-- Articles are public read (anyone can view the feed, logged in or not)
alter table articles enable row level security;

drop policy if exists "Anyone can read articles" on articles;
create policy "Anyone can read articles"
  on articles for select
  using (true);

-- Inserts happen only from the ingestion script using the service role key,
-- which bypasses RLS automatically — no insert policy needed for anon/auth users.

-- User preferences are private to each user
alter table user_preferences enable row level security;

drop policy if exists "Users manage own preferences" on user_preferences;
create policy "Users manage own preferences"
  on user_preferences for all
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);
